import { Header } from './Header/Header.component';
import { TableSection } from './TableSection/Table.component'
export { Header, TableSection }